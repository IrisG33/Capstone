package edu.cmu.cs.cs214.hw0;

public class Person {
	private String name;
	
	/*
	 * constructor 
	 */
	public Person(String name){
		this.name = name;
	}

	/*
	 * get the name of the person
	 */
	public String getName() {
		return name;
	}
	
}
