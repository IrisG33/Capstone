  $(function() {
    $( ".datepicker" ).datepicker({
      changeMonth: true,
      changeYear: true,
	  yearRange: '1900:2100'
    });
  });
